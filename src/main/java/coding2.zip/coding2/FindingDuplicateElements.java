package coding2;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class FindingDuplicateElements {

	int array[]= {1,3,3,3,3,5,6,6,7,7,7};
	long startTime;
	long endTime;

	@BeforeMethod
	public void startTimer() {
		startTime = System.nanoTime();
	}
	@AfterMethod
	public void endTimer() {
		endTime = System.nanoTime();
		System.out.println(endTime - startTime);
	}
	@Test(priority=1)
	public void usingSet() {
		int n=array.length;
		Set<Integer> dupNumbers = new LinkedHashSet<Integer>();
		for(int i=0;i<n;i++) {
			for(int j=i+1;j<n;j++) {
				if(array[j]==array[i]) {
					dupNumbers.add(array[i]); 
				}
			}
		}
		System.out.println(dupNumbers);
		System.out.println();
	}
	@Test(priority=2)
	public void usingArraysSort() {
		Arrays.sort(array);
		String repeatedNum = "";
		for (int i = 0; i < array.length -1 ; i++) {
			if(array[i] == array[i+1]){
				if (!repeatedNum.equals(array[i]+" ")) {
					repeatedNum = array[i] +" ";
					System.out.print(repeatedNum);
					System.out.println();
				}
			}
		}
	}
	@Test(priority=3)
	public void findDupicateInArray() {
		int[] a={1,3,3,3,3,5,6,6,7,7,7};
        int count=0;
        for(int j=0;j<a.length;j++) {
            for(int k =j+1;k<a.length;k++) {
                if(a[j]==a[k]) {
                    count++;
                }
            }
            if(count==1)
               System.out.println(a[j]);
            count = 0;
        }
    }

}