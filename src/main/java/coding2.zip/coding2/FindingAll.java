package coding2;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class FindingAll {
	long startTime;
	long endTime;

	@BeforeMethod
	public void startTimer() {
		startTime = System.nanoTime();
	}
	@AfterMethod
	public void endTimer() {
		endTime = System.nanoTime();
		System.out.println(endTime - startTime);
	}
	@Test
	public void findingAll() {
		String test = "$$ Welcome to 1st Automation Interview $$ ";
		char[] ch = test.toCharArray();
		int letter = 0, space = 0, num = 0, specialChar = 0;
		for(int i = 0; i < test.length(); i++){
			if(Character.isLetter(ch[i])){
				letter ++ ;
			}
			else if(Character.isDigit(ch[i])){
				num ++ ;
			}
			else if(Character.isSpaceChar(ch[i])){
				space ++ ;
			}
			else{
				specialChar ++;
			}}
		System.out.println("$$ Welcome to 1st Automation Interview $$ ");
		System.out.println("letter: " + letter);
		System.out.println("space: " + space);
		System.out.println("number: " + num);
		System.out.println("specialCharcter: " + specialChar);

	}
}
