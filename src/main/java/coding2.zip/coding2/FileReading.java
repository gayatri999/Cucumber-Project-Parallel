package coding2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class FileReading {
	long startTime;
	long endTime;

	@BeforeMethod
	public void startTimer() {
		startTime = System.nanoTime();

	}

	@AfterMethod
	public void endTimer() {
		endTime = System.nanoTime();
		System.out.println(endTime - startTime);
	}
	@Test(priority=1)
	public void fileRead() {
		String fileName = "MyFile.txt";
		String line =null;
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			try {
				while((line = br.readLine())!= null) {
					System.out.println(line);
				}
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}} catch (FileNotFoundException e) {
				e.printStackTrace();

}
}
	@Test(priority=2)
	public void read() throws FileNotFoundException {
		File file =  new File("DataFile.txt");
				Scanner sc = new Scanner(file);

				while (sc.hasNextLine())
					System.out.println(sc.nextLine());
		         sc.close();
			}

}