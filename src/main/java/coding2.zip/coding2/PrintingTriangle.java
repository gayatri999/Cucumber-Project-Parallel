package coding2;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class PrintingTriangle {
	long startTime;
	long endTime;

	@BeforeMethod
	public void startTimer() {
		startTime = System.nanoTime();
    }
	@AfterMethod
	public void endTimer() {
		endTime = System.nanoTime();
		System.out.println(endTime - startTime);
	}
	@Test(priority=1)
	public  void main() {
		int i, j;
		int n = 4;

		// outer loop to handle number of rows
		//  n in this case
		for(i=0; i<n; i++){
			//  inner loop to handle number of columns
			//  values changing acc. to outer loop  
			for(j=0; j<=i; j++){
				// printing stars
				System.out.print("* ");
			}

			// ending line after each row
			System.out.println();
		}
	}
	@Test(priority=2)
	public  void printStar() {
		int num;
		int n=5;
		for (int i = 0; i < n; i++) {
			num =1;
			for (int j = 0; j <=i; j++) {
				System.out.println(num+ " ");
				num++;
			}
			System.out.println();
		}
	}
}

