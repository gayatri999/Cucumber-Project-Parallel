package coding2;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class FingingPrime {
	long startTime;
	long endTime;

	@BeforeMethod
	public void startTimer() {
		startTime = System.nanoTime();

	}

	@AfterMethod
	public void endTimer() {
		endTime = System.nanoTime();
		System.out.println(endTime - startTime);
	}
	static boolean isPrime(int n) {
		for(int i=2;i<n;i++) {
			if(n%i==0)
				return false;
		}
		return true;
	}
	//priority=1
public static void main(String[] args) {
		boolean prime = isPrime(17);
		System.out.println(prime);
}
@Test(priority=2)
public void findingPrime() {
	  int num = 17, count;

	  for (int i = 1; i <= num; i++) {
	   count = 0;
	   for (int j = 2; j <= i / 2; j++) {
	    if (i % j == 0) {
	     count++;
	     break;
	    }
	   }
	   if (count == 0) {
	    System.out.println(i);
	   }

	  }
	 }

}

